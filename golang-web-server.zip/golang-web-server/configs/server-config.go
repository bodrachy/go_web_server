package configs

const (
	SERVER_STATIC_DIRECTORY string = "./web/static"
	SERVER_URL              string = "localhost"
	SERVER_PORT             string = "8081"
)
